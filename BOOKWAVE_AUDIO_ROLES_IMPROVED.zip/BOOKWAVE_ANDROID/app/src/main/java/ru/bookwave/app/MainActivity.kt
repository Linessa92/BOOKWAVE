package ru.bookwave.app

import android.app.Activity
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.content.pm.PackageManager
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Bundle as AndroidBundle
import java.io.File
import java.util.Locale
import org.json.JSONArray
import androidx.webkit.WebViewAssetLoader
import androidx.core.view.WindowCompat

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 4107
    private val selectedFiles = mutableMapOf<String, Uri>()
    @Volatile private var offlineTts: TextToSpeech? = null
    @Volatile private var offlineTtsReady = false
    private val pendingUtterances = mutableMapOf<String, File>()

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 5201)
        }
        window.statusBarColor = android.graphics.Color.rgb(33, 19, 47)
        window.navigationBarColor = android.graphics.Color.rgb(33, 19, 47)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.decorView.systemUiVisibility = 0
        }
        // Use the Android device's currently selected TTS engine (Samsung, Google, or another
        // installed engine). Do not assume that WebView implements browser speechSynthesis.
        offlineTts = TextToSpeech(this) { status ->
            offlineTtsReady = status == TextToSpeech.SUCCESS
            if (offlineTtsReady) {
                try { offlineTts?.language = Locale("ru", "RU") } catch (_: Exception) { }
                offlineTts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String) {}
                    override fun onDone(utteranceId: String) {
                        if (utteranceId.startsWith("bw-play-")) {
                            runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript("window.onBookwaveNativeSpeakDone && window.onBookwaveNativeSpeakDone(true)", null) }
                        } else finishWav(utteranceId, null)
                    }
                    @Deprecated("Deprecated by Android")
                    override fun onError(utteranceId: String) { onError(utteranceId, -1) }
                    override fun onError(utteranceId: String, errorCode: Int) {
                        if (utteranceId.startsWith("bw-play-")) {
                            runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript("window.onBookwaveNativeSpeakDone && window.onBookwaveNativeSpeakDone(false)", null) }
                        } else finishWav(utteranceId, "TTS error $errorCode")
                    }
                })
            }
        }
        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(25, 15, 34))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.setSupportMultipleWindows(false)
        webView.addJavascriptInterface(NativeAudioBridge(), "BookwaveAndroid")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                        "application/epub+zip", "application/pdf", "text/plain",
                        "audio/*", "application/octet-stream"
                    ))
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                return try {
                    startActivityForResult(intent, filePickerRequest)
                    true
                } catch (_: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun finishWav(id: String, error: String?) {
        val file = synchronized(pendingUtterances) { pendingUtterances.remove(id) }
        runOnUiThread {
            val safeName = file?.name ?: ""
            val js = "window.onBookwaveWavDone && window.onBookwaveWavDone(${org.json.JSONObject.quote(safeName)}, ${org.json.JSONObject.quote(error ?: "")});"
            if (::webView.isInitialized) webView.evaluateJavascript(js, null)
        }
    }

    private fun displayName(uri: Uri): String {
        var result = uri.lastPathSegment ?: "audio"
        val cursor: Cursor? = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        cursor?.use {
            if (it.moveToFirst()) result = it.getString(0) ?: result
        }
        return result
    }

    @Deprecated("Deprecated for WebView file chooser compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == filePickerRequest) {
            val uris = mutableListOf<Uri>()
            if (resultCode == RESULT_OK && data != null) {
                data.clipData?.let { clip ->
                    for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
                } ?: data.data?.let { uris.add(it) }
                uris.forEach { uri ->
                    try {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (_: Exception) { }
                    val name = displayName(uri)
                    selectedFiles[name] = uri
                    getSharedPreferences("bookwave_files", MODE_PRIVATE).edit()
                        .putString("uri_" + name, uri.toString()).apply()
                }
            }
            filePathCallback?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
            filePathCallback = null
        }
    }

    inner class NativeAudioBridge {
        @JavascriptInterface fun isOfflineTtsReady(): Boolean = offlineTtsReady
        @JavascriptInterface fun isTtsReady(): Boolean = offlineTtsReady

        // Return all Russian voices from the active Android TTS engine. Network voices are
        // available for live reading; WAV export filters them out because export is offline-only.
        @JavascriptInterface fun availableRussianVoices(): String {
            val result = JSONArray()
            val voices = offlineTts?.voices ?: emptySet()
            voices.filter { it.locale.language.equals("ru", true) }
                .sortedWith(compareBy({ it.isNetworkConnectionRequired }, { it.name }))
                .forEach { result.put(org.json.JSONObject().put("name", it.name).put("label", it.name)
                    .put("locale", it.locale.toLanguageTag()).put("network", it.isNetworkConnectionRequired)) }
            return result.toString()
        }

        @JavascriptInterface fun offlineVoices(): String {
            val result = JSONArray()
            val voices = offlineTts?.voices ?: emptySet()
            voices.filter { it.locale.language.equals("ru", true) && !it.isNetworkConnectionRequired }
                .sortedBy { it.name }.forEach { result.put(org.json.JSONObject().put("name", it.name).put("label", it.name).put("locale", it.locale.toLanguageTag())) }
            return result.toString()
        }

        @JavascriptInterface fun speakText(text: String, rate: Float, voiceName: String): Boolean {
            val engine = offlineTts ?: return false
            if (!offlineTtsReady || text.isBlank()) return false
            return try {
                val voice = engine.voices?.firstOrNull { it.name == voiceName }
                if (voice != null) engine.voice = voice
                if (voice == null && engine.isLanguageAvailable(Locale("ru", "RU")) < TextToSpeech.LANG_AVAILABLE) return false
                engine.setSpeechRate(rate.coerceIn(0.65f, 1.5f))
                val id = "bw-play-${System.currentTimeMillis()}"
                engine.speak(text, TextToSpeech.QUEUE_FLUSH, AndroidBundle(), id) == TextToSpeech.SUCCESS
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun stopSpeaking() { try { offlineTts?.stop() } catch (_: Exception) { } }

        @JavascriptInterface fun openTtsSettings() {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
            catch (_: Exception) { try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) } catch (_: Exception) { } }
        }

        @JavascriptInterface fun synthesizeWav(text: String, baseName: String, rate: Float, voiceName: String): Boolean {
            if (!offlineTtsReady || text.isBlank()) return false
            val engine = offlineTts ?: return false
            return try {
                val voice = engine.voices?.firstOrNull { it.name == voiceName }
                if (voice != null) engine.voice = voice
                engine.setSpeechRate(rate.coerceIn(0.7f, 1.4f))
                val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC) ?: filesDir
                if (!dir.exists()) dir.mkdirs()
                val safe = baseName.replace(Regex("[^a-zA-Z0-9А-Яа-я_-]"), "_").take(48)
                val file = File(dir, "$safe-${System.currentTimeMillis()}.wav")
                val id = "bw-${System.currentTimeMillis()}-${(0..9999).random()}"
                synchronized(pendingUtterances) { pendingUtterances[id] = file }
                val params = AndroidBundle()
                val result = engine.synthesizeToFile(text, params, file, id)
                if (result != TextToSpeech.SUCCESS) {
                    synchronized(pendingUtterances) { pendingUtterances.remove(id) }
                    false
                } else true
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun listOfflineWavs(): String {
            val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC) ?: filesDir
            val arr = JSONArray()
            dir.listFiles()?.filter { it.isFile && it.extension.equals("wav", true) }?.sortedByDescending { it.lastModified() }?.forEach {
                arr.put(org.json.JSONObject().put("name", it.name).put("path", it.absolutePath).put("bytes", it.length()))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun playBackgroundAudio(fileName: String): Boolean {
            val prefs = getSharedPreferences("bookwave_files", MODE_PRIVATE)
            val uri = selectedFiles[fileName]
                ?: selectedFiles.entries.firstOrNull { it.key.equals(fileName, ignoreCase = true) }?.value
                ?: prefs.getString("uri_" + fileName, null)?.let { Uri.parse(it) }
                ?: return false
            val intent = Intent(this@MainActivity, PlaybackService::class.java).apply {
                action = PlaybackService.ACTION_PLAY
                putExtra(PlaybackService.EXTRA_URI, uri.toString())
                putExtra(PlaybackService.EXTRA_TITLE, fileName)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                startForegroundService(intent)
                return true
            } catch (_: Exception) {
                return false
            }
        }

        @JavascriptInterface fun pause() = PlaybackService.pausePlayback()
        @JavascriptInterface fun resume() = PlaybackService.resumePlayback()
        @JavascriptInterface fun seekTo(seconds: Double) = PlaybackService.seekToSeconds(seconds.toLong())
        @JavascriptInterface fun positionMs(): Long = PlaybackService.positionMs()
        @JavascriptInterface fun durationMs(): Long = PlaybackService.durationMs()
        @JavascriptInterface fun isPlaying(): Boolean = PlaybackService.isPlaying()
        @JavascriptInterface fun stop() = PlaybackService.stopPlayback()
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        try { offlineTts?.stop(); offlineTts?.shutdown() } catch (_: Exception) {}
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
