# BOOKWAVE Android project — v1.0

Это Android Studio-проект-оболочка для локального приложения BOOKWAVE.

## Возможности первой сборки
- Нативное Android-приложение с названием и иконкой BOOKWAVE.
- Встроенный WebView с локальными ресурсами приложения.
- Нативный Android Media3/ExoPlayer MediaSessionService для фонового аудио и системных media controls.
- Выбор файлов через системный Android-пикер (множественный выбор).
- Локальная библиотека через IndexedDB.
- Читалка TXT/PDF/EPUB и аудиоплеер из веб-интерфейса.
- Светлая/тёмная тема.
- Минимальная версия Android 8.0 (API 26).

## Как собрать APK
1. Установите Android Studio (актуальную версию) и Android SDK Platform 35.
2. Откройте папку `BOOKWAVE_ANDROID` через **File → Open**.
3. Дождитесь Gradle Sync. Используйте JDK 17.
4. Выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Важные ограничения текущей версии
- Это исходный Android Studio-проект, а не уже собранный/подписанный APK. В среде подготовки нет Android SDK и Gradle, поэтому локально скомпилировать и проверить APK здесь невозможно.
- Аудиофайлы воспроизводятся встроенным плеером WebView. Надёжное фоновое воспроизведение с системным уведомлением/MediaSession — отдельный следующий этап.
- PDF открывается средствами браузерного WebView; EPUB использует epub.js из CDN, поэтому для EPUB нужен интернет при загрузке библиотеки движка.
- Библиотека хранится в локальном IndexedDB приложения. Удаление данных приложения удалит и библиотеку; сохраняйте оригиналы файлов.
- Поддержка DRM-защищённых книг не предусмотрена.
- Приложение не содержит готового каталога книг: оно работает с файлами пользователя.

## Технический стек
Kotlin, Android WebView, AndroidX WebKit WebViewAssetLoader, HTML/CSS/JavaScript, IndexedDB.


## BOOKWAVE V1.2 additions
- Library sort: newest, title, reading/listening progress.
- Delete an imported item from the library.
- Persist progress for TXT and EPUB reading, and audio playback.
- Save a reading bookmark for TXT/EPUB; PDF can be marked as bookmarked.
- Native Android Media3 playback service remains included in the Android project.


## BOOKWAVE V1.3 — product polish
- Custom typographic book-cover treatments with varied editorial palettes.
- Individual book detail sheet with file information, progress, bookmark action, and open/listen action.
- Library summary cards for books, audiobooks, and average progress.
- Branded launch screen.
- Native Android media playback bridge now persists selected document URIs for later sessions.
- Android 13+ notification permission prompt added for lock-screen/notification media controls.

## Build environment note
The project has not been compiled in this workspace: Android SDK, Gradle, and an Android emulator/device are not installed here. Open in Android Studio with JDK 17, install Android SDK Platform 35, then run Gradle sync and Build APK. Before release, test document-picker imports, EPUB/PDF rendering, background playback, and notification controls on physical Android devices.


## BOOKWAVE V1.4 — reader's personal space
- Favorites toggle and dedicated Favorites filter.
- Personal quote collection with copy/delete actions.
- Save selected TXT passages as quotes (or enter a quote manually).
- Library metrics include total saved quotes and estimated reading/listening time.
- Responsive summary cards for compact phone screens.
- Custom adaptive Android launcher icon.
- Added Gradle bootstrap scripts (`gradlew` / `gradlew.bat`) that download Gradle 8.9 when needed.

### Build
From the project root, run `./gradlew :app:assembleDebug` (macOS/Linux) or `gradlew.bat :app:assembleDebug` (Windows), after installing Android SDK Platform 35 and JDK 17. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.


## BOOKWAVE V1.4 — library features
- Favorites toggle and dedicated Favorites filter.
- Personal quote collection with copy/delete actions.
- Save selected TXT passages as quotes, or enter a quote manually.
- Library metrics include saved quotes and estimated reading/listening time.
- Responsive summary cards for compact phone screens.
- Adaptive Android launcher icon.
- Android Media3 player bridge marshals player commands to the main thread and exposes cached playback state to the web UI.

## Build from this project
1. Install Android Studio, JDK 17, and Android SDK Platform 35.
2. Open this folder in Android Studio, or run `./gradlew :app:assembleDebug` on macOS/Linux (`gradlew.bat :app:assembleDebug` on Windows).
3. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Verification status
The web UI JavaScript syntax and Android XML files were checked. The APK has **not** been compiled or tested on a physical Android device in this workspace because Android SDK/build tools are not installed here. Test imports, EPUB/PDF display, Android 13+ notifications, lock-screen controls, and background playback on target devices before distributing the app.

## Облачная сборка APK без Android Studio
В проект добавлен GitHub Actions workflow: `.github/workflows/android-apk.yml`.
1. Создайте репозиторий на GitHub и загрузите в него **содержимое** папки `BOOKWAVE_ANDROID` (не сам ZIP-файл).
2. Откройте вкладку **Actions** репозитория.
3. Выберите workflow **Build BOOKWAVE APK** и нажмите **Run workflow** (если workflow ещё не запускался автоматически после загрузки в `main`).
4. Дождитесь зелёного статуса выполнения. Внизу страницы запуска, в разделе **Artifacts**, скачайте `BOOKWAVE-debug-APK`.
5. Распакуйте скачанный ZIP-архив на телефоне и откройте `app-debug.apk` для установки.

Для установки Android может попросить разрешить установку приложений из браузера или файлового менеджера. Разрешайте её только для APK, полученного из вашего собственного GitHub Actions запуска. Это тестовая debug-сборка, не релизная версия для Google Play.
