@echo off
setlocal
set GRADLE_VERSION=8.9
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set GRADLE_HOME=%GRADLE_USER_HOME%\bookwave-gradle\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%GRADLE_USER_HOME%\bookwave-gradle" mkdir "%GRADLE_USER_HOME%\bookwave-gradle"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; $z='%GRADLE_USER_HOME%\bookwave-gradle\gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest $u -OutFile $z; Expand-Archive -Force $z '%GRADLE_USER_HOME%\bookwave-gradle'"
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
