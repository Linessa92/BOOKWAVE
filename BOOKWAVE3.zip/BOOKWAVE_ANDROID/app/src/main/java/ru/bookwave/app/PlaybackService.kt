package ru.bookwave.app

import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        player = ExoPlayer.Builder(this).build()
        mediaSession = MediaSession.Builder(this, player!!).build()
        player?.addListener(object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playingState = isPlaying }
            override fun onPlaybackStateChanged(playbackState: Int) { refreshPlayerSnapshot() }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { refreshPlayerSnapshot() }
        })
        mainHandler.post(snapshotRunnable)
    }

    private fun refreshPlayerSnapshot() {
        val p = player ?: return
        positionSnapshot = p.currentPosition.coerceAtLeast(0L)
        durationSnapshot = p.duration.takeIf { it > 0L } ?: 0L
        playingState = p.isPlaying
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_PLAY -> {
                val rawUri = intent.getStringExtra(EXTRA_URI)
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "BOOKWAVE"
                if (rawUri != null) {
                    val metadata = MediaMetadata.Builder().setTitle(title).setArtist("BOOKWAVE").build()
                    val item = MediaItem.Builder()
                        .setUri(Uri.parse(rawUri))
                        .setMediaMetadata(metadata)
                        .build()
                    player?.setMediaItem(item)
                    player?.prepare()
                    player?.play()
                }
            }
            ACTION_PAUSE -> player?.pause()
            ACTION_RESUME -> player?.play()
            ACTION_SEEK -> player?.seekTo(intent.getLongExtra(EXTRA_POSITION, 0L))
            ACTION_STOP -> {
                player?.stop()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(snapshotRunnable)
        instance = null
        playingState = false
        positionSnapshot = 0L
        durationSnapshot = 0L
        mediaSession?.release()
        mediaSession = null
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "ru.bookwave.app.PLAY"
        const val ACTION_PAUSE = "ru.bookwave.app.PAUSE"
        const val ACTION_RESUME = "ru.bookwave.app.RESUME"
        const val ACTION_SEEK = "ru.bookwave.app.SEEK"
        const val ACTION_STOP = "ru.bookwave.app.STOP"
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
        const val EXTRA_POSITION = "position"

        @Volatile private var instance: PlaybackService? = null
        @Volatile private var playingState = false
        @Volatile private var positionSnapshot = 0L
        @Volatile private var durationSnapshot = 0L
        private val mainHandler = Handler(Looper.getMainLooper())

        private val snapshotRunnable = object : Runnable {
            override fun run() {
                instance?.refreshPlayerSnapshot()
                mainHandler.postDelayed(this, 500L)
            }
        }

        private fun postPlayerAction(action: (ExoPlayer) -> Unit) {
            mainHandler.post { instance?.player?.let(action) }
        }

        fun pausePlayback() { postPlayerAction { it.pause() } }
        fun resumePlayback() { postPlayerAction { it.play() } }
        fun seekToSeconds(seconds: Long) { postPlayerAction { it.seekTo(seconds.coerceAtLeast(0L) * 1000L) } }
        fun positionMs(): Long = positionSnapshot
        fun durationMs(): Long = durationSnapshot
        fun isPlaying(): Boolean = playingState
        fun stopPlayback() { postPlayerAction { it.stop() }; mainHandler.post { instance?.stopSelf() } }
    }
}
